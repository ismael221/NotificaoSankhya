<%@ page language="java" contentType="text/html; charset=ISO-8859-1" pageEncoding="UTF-8" isELIgnored ="false"%>
<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<%@ page import="java.util.*" %>
<%@ taglib uri="http://java.sun.com/jstl/core_rt" prefix="c" %>
<%@ taglib prefix="snk" uri="/WEB-INF/tld/sankhyaUtil.tld" %>
<html>
<head>
	<title>HTML5 Component</title>
	<link rel="stylesheet" type="text/css" href="${BASE_FOLDER}css/mainCSS.css">
	<snk:load/>
</head>
<body>
    <iframe id="adminFrame" src="/mge/AdministracaoServidor.xhtml5?resourceID=br.com.sankhya.core.cfg.AdministracaoServidor&html5ScreenChoice=S&changeLayout=S&isFirstAccess=N&betaApp=false&newLayoutSupChoice=S#" style="width: 100%; height: 100%; position: absolute; left: 0px;"></iframe>

<script>
    window.onload = function () {
           const iframe = document.getElementById('adminFrame');
           iframe.onload = function () {
               try {

                   const doc = iframe.contentWindow.document;
                   console.log("aaaaaaaaaaaaaaa",doc)
                   const el = win.document.querySelector('sk-tabnavigator-item[sk-label="Notificações"] > div');
                   const scope = win.angular.element(el).scope();
                   console.log(scope);
                   doc.querySelector('sk-tabnavigator-item[sk-label="Notificações"] > div').click();

               } catch (e) {
                   console.error("Erro ao manipular iframe:", e);
               }
           };
       };
</script>
</body>
</html>